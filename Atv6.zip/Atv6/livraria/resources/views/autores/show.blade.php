ID:{{$autor->id_autor}}<br>
Nome:{{$autor->nome}}<br>
nacionalidade:{{$autor->nacionalidade}}
@foreach ($autores->livros as $livro)
<h3>{{$livro->titulo}}</h3>
@endforeach